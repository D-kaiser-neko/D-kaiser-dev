/* ============================================================
 * D-kaiser Music 前端主逻辑（自包含单文件）
 * 依赖: index.html 中的 ID/class（已核对）
 * 后端: /api/search /api/download /api/preview /api/lyric
 *       /api/cookie /api/dl-status /api/dl-remove /api/dl-clear
 *       /api/logs-stream (SSE)
 * ============================================================ */
(function () {
'use strict';

/* ================= 工具函数 ================= */
var $  = function (s) { return document.querySelector(s); };
var $$ = function (s) { return Array.prototype.slice.call(document.querySelectorAll(s)); };

function esc(s) {
  return (s == null ? '' : String(s))
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function fmt(t) {
  t = Math.max(0, Math.floor(t || 0));
  var m = Math.floor(t / 60), s = t % 60;
  return (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
}
function toast(msg) {
  var el = $('#toast'); if (!el) return;
  el.textContent = msg; el.classList.add('show');
  clearTimeout(el._t);
  el._t = setTimeout(function () { el.classList.remove('show'); }, 1800);
}
function post(url, body) {
  return fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body || {})
  }).then(function (r) { return r.json(); });
}
function get(url) { return fetch(url).then(function (r) { return r.json(); }); }

/* ================= 全局状态 ================= */
var state = {
  source: 'muguang',  // 当前音源 muguang | hi
  page: 1,            // 搜索页码
  total: 0,           // 搜索总条数
  songs: [],          // 当前搜索结果 = 播放队列
  cur: -1,            // 当前播放索引
  lyrics: [],         // [{t:秒, x:文本}]
  lyricIdx: -1
};
var audio = $('#audio-element');
var seenDone = {};    // 下载完成 toast 去重
var firstPoll = true; // 首次轮询不弹历史完成提示

/* ================= 页面切换（顶部4 Tab） ================= */
function switchPage(name) {
  $$('.nav-tab').forEach(function (b) {
    b.classList.toggle('active', b.dataset.page === name);
  });
  $$('.page').forEach(function (p) {
    p.classList.toggle('active', p.id === 'page-' + name);
  });
  if (name === 'download') {
    pollDl();
    var lb = $('#logBody'); if (lb) lb.scrollTop = lb.scrollHeight;
  }
}

/* ================= 搜索 ================= */
function doSearch(page) {
  var input = $('#searchInput');
  var kw = input ? input.value.trim() : '';
  if (!kw) { toast('请输入关键词'); return; }
  state.page = page || 1;
  var box = $('#searchResult');
  if (box) box.innerHTML = '<p class="empty-hint">搜索中...</p>';
  post('/api/search', { keyword: kw, source: state.source, page: state.page })
    .then(function (d) {
      state.songs = (d && d.songs) ? d.songs : [];
      state.total = (d && d.total) ? d.total : 0;
      renderSongs();
      renderCurrentPlaylist();
    })
    .catch(function () {
      if (box) box.innerHTML = '<p class="empty-hint">搜索失败，请重试</p>';
    });
}

/* 搜索结果: [序号][F红/M绿][歌名][作者][▶][⬇] */
function renderSongs() {
  var box = $('#searchResult'); if (!box) return;
  var pag = $('#pagination');
  if (!state.songs.length) {
    box.innerHTML = '<p class="empty-hint">没有结果</p>';
    if (pag) pag.style.display = 'none';
    return;
  }
  var base = (state.page - 1) * 20;
  box.innerHTML = state.songs.map(function (s, i) {
    var fl = (s.minfo || []).some(function (m) { return m.format === 'flac'; }) || s.hasLossless;
    return '<div class="song-row" data-i="' + i + '">'
      + '<span class="song-idx">' + (base + i + 1) + '</span>'
      + '<span class="song-q ' + (fl ? 'q-flac' : 'q-mp3') + '">' + (fl ? 'F' : 'M') + '</span>'
      + '<span class="song-name" title="' + esc(s.name) + '">' + esc(s.name) + '</span>'
      + '<span class="song-artist">' + esc(s.artist || '') + '</span>'
      + '<span class="song-ops">'
      +   '<button class="op-play" data-i="' + i + '" title="播放">▶</button>'
      +   '<button class="op-dl" data-i="' + i + '" title="下载">⬇</button>'
      + '</span></div>';
  }).join('');

  var pages = Math.max(1, Math.ceil(state.total / 20));
  if (pag) {
    pag.style.display = 'flex';
    var info = $('#pageInfo'); if (info) info.textContent = state.page + ' / ' + pages;
    var pv = $('#btnPrevPage'); if (pv) pv.disabled = state.page <= 1;
    var nx = $('#btnNextPage'); if (nx) nx.disabled = state.page >= pages;
  }

  $$('#searchResult .op-play').forEach(function (b) {
    b.addEventListener('click', function (e) { e.stopPropagation(); playIdx(+b.dataset.i); });
  });
  $$('#searchResult .op-dl').forEach(function (b) {
    b.addEventListener('click', function (e) { e.stopPropagation(); dlIdx(+b.dataset.i); });
  });
  $$('#searchResult .song-row').forEach(function (r) {
    r.addEventListener('click', function () { playIdx(+r.dataset.i); });
  });
}

/* ================= 播放 ================= */
function playIdx(i) {
  var s = state.songs[i]; if (!s) return;
  state.cur = i;
  setNow(s);
  pushHistory(s);
  renderCurrentPlaylist();
  post('/api/preview', { index: i, source: state.source }).then(function (d) {
    if (d && d.url) {
      audio.src = d.url;               // 后端代理地址 /api/stream?...
      var p = audio.play();
      if (p && p.catch) p.catch(function () { toast('已就绪，点击 ▶ 开始播放'); });
    } else {
      toast('无播放链接');
    }
  }).catch(function () { toast('获取播放链接失败'); });
  post('/api/lyric', { index: i, source: state.source }).then(function (d) {
    parseLyric(d && d.lrc);
  }).catch(function () { parseLyric(null); });
}

function setNow(s) {
  var t = s.name || '未命名', a = s.artist || '-';
  var pt = $('#playerTitle'); if (pt) pt.textContent = t;
  var pa = $('#playerArtist'); if (pa) pa.textContent = a;
  var mt = $('#miniTitle'); if (mt) mt.textContent = t;
  var ma = $('#miniArtist'); if (ma) ma.textContent = a;
  var pic = s.pic_url || s.pic || '';
  var pc = $('#playerCover'); if (pc) pc.src = pic;
  var mc = $('#miniCover'); if (mc) mc.src = pic;
}

function setPlayIcon(ch) {
  var a = $('#btnPlayPause'); if (a) a.textContent = ch;
  var b = $('#miniBtnPlayPause'); if (b) b.textContent = ch;
}
function togglePlay() {
  if (!audio.src) { toast('请先选择歌曲'); return; }
  if (audio.paused) audio.play(); else audio.pause();
}
function step(d) {
  var n = state.cur + d;
  if (n < 0 || n >= state.songs.length) { toast('到边界了'); return; }
  playIdx(n);
}
function bindSeek(bar) {
  if (!bar) return;
  bar.addEventListener('input', function () {
    if (audio.duration) audio.currentTime = bar.value / 100 * audio.duration;
  });
}

/* ================= 歌词解析与同步 ================= */
function parseLyric(text) {
  state.lyrics = []; state.lyricIdx = -1;
  var box = $('#lyricContainer'); if (!box) return;
  if (!text) { box.innerHTML = '<p class="lyric-empty">暂无歌词</p>'; return; }
  text.split('\n').forEach(function (line) {
    var m = /^\[(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?\](.*)$/.exec(line.trim());
    if (m && m[4]) {
      var ms = (m[3] || '0'); while (ms.length < 3) ms += '0';
      state.lyrics.push({ t: (+m[1]) * 60 + (+m[2]) + (+ms) / 1000, x: m[4] });
    }
  });
  state.lyrics.sort(function (a, b) { return a.t - b.t; });
  box.innerHTML = state.lyrics.length
    ? state.lyrics.map(function (l, i) {
        return '<p class="lyric-line" data-i="' + i + '">' + esc(l.x) + '</p>';
      }).join('')
    : '<p class="lyric-empty">暂无歌词</p>';
}

function bindAudio() {
  audio.addEventListener('timeupdate', function () {
    var t = audio.currentTime, d = audio.duration || 0;
    var ct = $('#currentTime'); if (ct) ct.textContent = fmt(t);
    var tt = $('#totalTime'); if (tt) tt.textContent = fmt(d);
    if (d) {
      var pv = t / d * 100;
      var pb = $('#progressBar'); if (pb) pb.value = pv;
      var mp = $('#miniProgress'); if (mp) mp.value = pv;
    }
    var idx = -1;
    for (var i = 0; i < state.lyrics.length; i++) {
      if (state.lyrics[i].t <= t) idx = i; else break;
    }
    if (idx !== state.lyricIdx) {
      state.lyricIdx = idx;
      $$('#lyricContainer .lyric-line').forEach(function (el, i) {
        el.classList.toggle('active', i === idx);
        if (i === idx) el.scrollIntoView({ block: 'center', behavior: 'smooth' });
      });
    }
  });
  audio.addEventListener('play',  function () { setPlayIcon('⏸'); });
  audio.addEventListener('pause', function () { setPlayIcon('▶'); });
  audio.addEventListener('ended', function () { step(1); });
  audio.addEventListener('error', function () {
    toast('音频加载失败(code=' + (audio.error ? audio.error.code : '?') + ')');
  });
}

/* ================= 播放列表: 当前播放 ================= */
function renderCurrentPlaylist() {
  var box = $('#plPanel-current'); if (!box) return;
  if (!state.songs.length) { box.innerHTML = '<p class="empty-hint">暂无播放列表</p>'; return; }
  box.innerHTML = state.songs.map(function (s, i) {
    var fl = (s.minfo || []).some(function (m) { return m.format === 'flac'; }) || s.hasLossless;
    var hl = (i === state.cur) ? ' style="background:rgba(29,185,84,.12)"' : '';
    return '<div class="song-row" data-i="' + i + '"' + hl + '>'
      + '<span class="song-idx">' + (i + 1) + '</span>'
      + '<span class="song-q ' + (fl ? 'q-flac' : 'q-mp3') + '">' + (fl ? 'F' : 'M') + '</span>'
      + '<span class="song-name">' + esc(s.name) + '</span>'
      + '<span class="song-artist">' + esc(s.artist || '') + '</span></div>';
  }).join('');
  $$('#plPanel-current .song-row').forEach(function (r) {
    r.addEventListener('click', function () { playIdx(+r.dataset.i); });
  });
}

/* ================= 播放历史 (localStorage) ================= */
function pushHistory(s) {
  try {
    var h = JSON.parse(localStorage.getItem('dk_history') || '[]');
    h = h.filter(function (x) { return x.id !== s.id; });
    h.unshift({ id: s.id, name: s.name, artist: s.artist, pic_url: s.pic_url });
    localStorage.setItem('dk_history', JSON.stringify(h.slice(0, 50)));
    renderHistory();
  } catch (e) {}
}
function renderHistory() {
  var box = $('#plPanel-history'); if (!box) return;
  var h = [];
  try { h = JSON.parse(localStorage.getItem('dk_history') || '[]'); } catch (e) {}
  if (!h.length) { box.innerHTML = '<p class="empty-hint">暂无播放历史</p>'; return; }
  box.innerHTML = h.map(function (s, i) {
    return '<div class="song-row" data-kw="' + esc(s.name) + '">'
      + '<span class="song-idx">' + (i + 1) + '</span>'
      + '<span class="song-name">' + esc(s.name) + '</span>'
      + '<span class="song-artist">' + esc(s.artist || '') + '</span></div>';
  }).join('');
  $$('#plPanel-history .song-row').forEach(function (r) {
    r.addEventListener('click', function () {
      var input = $('#searchInput'); if (input) input.value = r.dataset.kw;
      switchPage('search');
      doSearch(1);
    });
  });
}

/* ================= 下载管理 ================= */
function dlIdx(i) {
  post('/api/download', { indices: [i], source: state.source }).then(function (d) {
    toast('已加入下载 ' + ((d && d.count) || 0) + ' 首');   // 不跳转页面
    pollDl();
  }).catch(function () { toast('下载请求失败'); });
}

function pollDl() {
  get('/api/dl-status').then(function (d) {
    var p = (d && d.pending) || [], c = (d && d.completed) || [];
    var pc = $('#dlPendingCount'); if (pc) pc.textContent = p.length;
    var dc = $('#dlDoneCount'); if (dc) dc.textContent = c.length;

    var pl = $('#dlPendingList');
    if (pl) {
      pl.innerHTML = p.length ? p.map(function (t) {
        return '<li class="dl-item"><div class="dl-info">'
          + '<span class="dl-name">' + esc(t.name) + '</span>'
          + '<span class="dl-artist">' + esc(t.artist || '') + '</span></div>'
          + '<span class="dl-status">' + esc(t.status || '') + '</span>'
          + '<button class="dl-remove" data-id="' + t.id + '">✕</button></li>';
      }).join('') : '<li class="empty-hint">暂无下载任务</li>';
      $$('#dlPendingList .dl-remove').forEach(function (b) {
        b.addEventListener('click', function () {
          post('/api/dl-remove', { id: +b.dataset.id }).then(pollDl);
        });
      });
    }

    var dl = $('#dlDoneList');
    if (dl) {
      dl.innerHTML = c.length ? c.map(function (t) {
        return '<li class="dl-item"><div class="dl-info">'
          + '<span class="dl-name">' + esc(t.name) + '</span>'
          + '<span class="dl-artist">' + esc(t.artist || '') + '</span></div>'
          + '<span class="dl-status ' + (t.status === '成功' ? 'ok' : 'fail') + '">'
          + esc(t.status || '') + '</span></li>';
      }).join('') : '<li class="empty-hint">暂无已完成任务</li>';
    }

    if (!firstPoll) {
      c.forEach(function (t) {
        if (t.status === '成功' && !seenDone[t.id]) {
          seenDone[t.id] = 1;
          toast('✅ 下载完成: ' + t.name);
        }
      });
    }
    firstPoll = false;
  }).catch(function () {});
}

/* ================= 运行日志（内嵌下载页, SSE） ================= */
var es = null;
function logLine(text) {
  var b = $('#logBody'); if (!b) return;
  var d = document.createElement('div');
  d.textContent = text;
  b.appendChild(d);
  while (b.children.length > 300) b.removeChild(b.firstChild);
  b.scrollTop = b.scrollHeight;
}
function connectLog() {
  if (es) es.close();
  es = new EventSource('/api/logs-stream');
  es.onmessage = function (e) { logLine(e.data); };
  es.onerror = function () { setTimeout(connectLog, 3000); };
}

/* ================= 初始化 ================= */
function init() {
  // 顶部导航
  $$('.nav-tab').forEach(function (b) {
    b.addEventListener('click', function () { switchPage(b.dataset.page); });
  });
  // 播放列表子 Tab
  $$('.pl-tab').forEach(function (b) {
    b.addEventListener('click', function () {
      $$('.pl-tab').forEach(function (x) { x.classList.toggle('active', x === b); });
      $$('.pl-panel').forEach(function (p) { p.classList.toggle('active', p.id === 'plPanel-' + b.dataset.pltab); });
    });
  });
  // 搜索 & 分页
  var bs = $('#btnSearch'); if (bs) bs.addEventListener('click', function () { doSearch(1); });
  var si = $('#searchInput'); if (si) si.addEventListener('keydown', function (e) { if (e.key === 'Enter') doSearch(1); });
  var pv = $('#btnPrevPage'); if (pv) pv.addEventListener('click', function () { if (state.page > 1) doSearch(state.page - 1); });
  var nx = $('#btnNextPage'); if (nx) nx.addEventListener('click', function () { doSearch(state.page + 1); });
  // 换源 & Cookie
  $$('.src-btn').forEach(function (b) {
    b.addEventListener('click', function () {
      $$('.src-btn').forEach(function (x) { x.classList.toggle('active', x === b); });
      state.source = b.dataset.src || 'muguang';
      var cb = $('#cookieBox'); if (cb) cb.style.display = (state.source === 'hi') ? 'flex' : 'none';
    });
  });
  var sc = $('#btnSaveCookie');
  if (sc) sc.addEventListener('click', function () {
    var c = $('#cookieInput'); if (!c || !c.value.trim()) return;
    post('/api/cookie', { cookie: c.value.trim() }).then(function () { toast('Cookie 已保存'); });
  });
  // 播放控制
  var pp = $('#btnPlayPause'); if (pp) pp.addEventListener('click', togglePlay);
  var mb = $('#miniBtnPlayPause'); if (mb) mb.addEventListener('click', togglePlay);
  var bp = $('#btnPrev'); if (bp) bp.addEventListener('click', function () { step(-1); });
  var bn = $('#btnNext'); if (bn) bn.addEventListener('click', function () { step(1); });
  bindSeek($('#progressBar')); bindSeek($('#miniProgress'));
  // 迷你条点击 → 回播放器页
  var mini = $('#miniPlayer');
  if (mini) mini.addEventListener('click', function (e) {
    if (e.target.closest && (e.target.closest('button') || e.target.closest('input'))) return;
    switchPage('player');
  });
  // 下载管理按钮
  var cc = $('#btnClearCompleted');
  if (cc) cc.addEventListener('click', function () {
    post('/api/dl-clear').then(function () { seenDone = {}; pollDl(); });
  });
  var cl = $('#btnClearLog');
  if (cl) cl.addEventListener('click', function () {
    var b = $('#logBody'); if (b) b.innerHTML = '';
  });
  // 启动
  bindAudio();
  pollDl();
  setInterval(pollDl, 2000);
  connectLog();
  renderHistory();
  switchPage('player');
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
})();