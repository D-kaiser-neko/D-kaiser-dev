#!/usr/bin/env python3
"""暮光工具箱 API（签名 / 搜索 / 播放链接 / 歌词）"""
import time, hashlib, json, base64, zlib, urllib.parse
import requests
from config import MG_SEARCH, MG_PLAY, MG_LYRIC, MG_SALT, MG_SOURCE, PAGE_SIZE, log
from core.lrc_parser import format_lrc


def mg_headers():
    ts = str(int(time.time() * 1000))
    sign = hashlib.md5(f"{MG_SALT}{ts}1".encode()).hexdigest()
    return {
        "Version": "1", "Platform": "android",
        "Timestamp": ts, "Sign": sign,
        "User-Agent": "okhttp/4.11.0"
    }


def mg_search(keyword, page=1, size=PAGE_SIZE):
    url = f"{MG_SEARCH}?keyword={urllib.parse.quote(keyword)}&pageNo={page}&pageSize={size}"
    try:
        j = requests.get(url, headers=mg_headers(), timeout=15).json()
        if j.get("code") != 200:
            return [], 0
        d = j.get("data", {})
        songs = []
        for s in d.get("data", []):
            s["pic_url"] = s.get("pic", "")
            s["source_tag"] = "muguang"
            s["minfo"] = [{"format": "flac"}] if s.get("hasLossless") else [{"format": "mp3"}]
            songs.append(s)
        return songs, d.get("total", 0)
    except Exception as e:
        log(f"[-] 暮光搜索异常: {e}")
        return [], 0


def mg_play_url(rid, quality="flac"):
    br = {"flac": "2000kflac", "320": "320kmp3", "128": "128kmp3"}.get(quality, "2000kflac")
    params = {
        "f": "web", "user": "0", "source": MG_SOURCE,
        "type": "convert_url_with_sign", "rid": str(rid), "br": br
    }
    try:
        j = requests.get(MG_PLAY, params=params, headers={
            "User-Agent": "okhttp/4.11.0", "Accept-Encoding": "gzip"
        }, timeout=15).json()
        if j.get("code") == 200:
            d = j.get("data", {})
            return d.get("url"), d.get("format", quality)
        return None, None
    except Exception as e:
        log(f"[-] 播放链接异常: {e}")
        return None, None


def mg_lyrics(rid):
    """
    酷我歌词接口解码链路（已从抓包实测确认）:
      HTTP响应(bytes)
        → 跳过明文头 "TP=content\\r\\nlrcx=1\\r\\n\\r\\n"
        → zlib 解压 (魔数 0x78)
        → Base64 解码
        → 最终内容 (纯LRC文本 或 JSON包裹的LRC)
    """
    params = {"f": "web", "type": "lyric", "lrcx": "1", "rid": str(rid), "encode": "utf8"}
    try:
        r = requests.get(MG_LYRIC, params=params, headers={
            "User-Agent": "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120.0.6099.144 Mobile Safari/537.36",
            "Accept-Encoding": "identity"  # 关键: 禁止自动gzip, 拿原始字节
        }, timeout=15)

        data = r.content  # 必须用 bytes, 不能用 text
        if not data:
            return None

        # ---- 步骤1: 跳过明文头 ----
        payload = data
        for sep in (b"\r\n\r\n", b"\n\n"):
            pos = data.find(sep)
            if pos != -1 and pos < 200:
                payload = data[pos + len(sep):]
                break

        # ---- 步骤2: 定位 zlib 魔数并解压 ----
        decompressed = None
        for i in range(min(len(payload), 32)):
            if payload[i] == 0x78 and i + 1 < len(payload) and payload[i + 1] in (0x01, 0x5e, 0x9c, 0xda):
                try:
                    decompressed = zlib.decompress(payload[i:])
                    break
                except zlib.error:
                    continue

        if decompressed is None:
            # 没有 zlib 流, 直接当文本处理
            decompressed = payload

        # ---- 步骤3: 解压结果是 Base64 字符串, 再解码 ----
        try:
            b64_str = decompressed.decode("utf-8", errors="replace").strip()
            final_bytes = base64.b64decode(b64_str)
            raw_text = final_bytes.decode("utf-8", errors="replace")
        except Exception:
            # 不是 Base64, 直接当文本
            raw_text = decompressed.decode("utf-8", errors="replace")

        if not raw_text or not raw_text.strip():
            return None

        # ---- 步骤4: 从最终文本中提取歌词 ----
        lrc_text = None

        # 尝试 JSON 解析
        try:
            j = json.loads(raw_text)
            if isinstance(j, dict):
                # {"data": "..."} 或 {"content": "..."}
                for key in ("data", "content", "lyric", "lrc"):
                    v = j.get(key)
                    if isinstance(v, str) and "[" in v:
                        lrc_text = v
                        break
                # {"lrclist": [{"time":"0.0","lineLyric":"..."}]}
                if not lrc_text:
                    arr = j.get("lrclist") or (j.get("data", {}) or {}).get("lrclist")
                    if isinstance(arr, list) and arr:
                        lines = []
                        for it in arr:
                            if not isinstance(it, dict):
                                continue
                            t = float(it.get("time", 0) or 0)
                            mm, ss = divmod(t, 60)
                            lyric = it.get("lineLyric") or it.get("lyric") or ""
                            if lyric.strip():
                                lines.append(f"[{int(mm):02d}:{ss:05.2f}]{lyric}")
                        if lines:
                            lrc_text = "\n".join(lines)
        except (ValueError, TypeError):
            pass

        # 不是 JSON, 直接当 LRC
        if not lrc_text and "[" in raw_text:
            lrc_text = raw_text

        if not lrc_text:
            log(f"[-] 歌词内容为空或无法解析 rid={rid}")
            return None

        result = format_lrc(lrc_text)
        if result:
            log(f"[✅] 歌词已解析 rid={rid} 长度={len(result)}")
            return result

        # format_lrc 过滤后为空, 返回原始文本兜底
        log(f"[!] format_lrc 为空, 返回原始文本 rid={rid}")
        return lrc_text

    except Exception as e:
        log(f"[-] 歌词请求异常: {e}")
        return None