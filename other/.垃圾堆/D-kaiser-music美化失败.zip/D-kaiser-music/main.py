#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
D-kaiser Music Web Console — 启动入口
用法: python main.py
访问: http://localhost:8888
"""
#!/usr/bin/env python3
"""D-kaiser Music Web Console — 启动入口"""
import sys
import os

# ★ 禁止生成 __pycache__（必须在导入本地模块之前）
sys.dont_write_bytecode = True

import shutil
import atexit
import signal
import hashlib


# ================= 清理钩子 =================
def cleanup_workspace():
    print("\n[*] 正在清理临时文件...")
    try:
        base_dir = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        base_dir = os.getcwd()

    for root, dirs, files in os.walk(base_dir, topdown=False):
        for d in list(dirs):
            if d == "__pycache__":
                p = os.path.join(root, d)
                try:
                    shutil.rmtree(p, ignore_errors=True)
                except Exception:
                    pass
        for f in files:
            if f.endswith(".bak"):
                p = os.path.join(root, f)
                try:
                    os.remove(p)
                except Exception:
                    pass


atexit.register(cleanup_workspace)

def _exit_handler(sig, frame):
    cleanup_workspace()
    sys.exit(0)

signal.signal(signal.SIGINT, _exit_handler)
signal.signal(signal.SIGTERM, _exit_handler)


# ================= 业务导入 =================
from config import PORT, MG_SALT, MG_SEARCH, MG_PLAY, MG_LYRIC, HI_HEADERS, log
from core.kuwo_hi_api import hi_load_cookie
from server.http_handler import Handler


def main():
    ck = hi_load_cookie()
    if ck:
        HI_HEADERS["Cookie"] = ck
        log("[✅] Cookie 已加载")
    else:
        log("[⚠️] 未找到Cookie (仅酷我聚合源需要)")

    # 签名验证
    test_ts = "1792859066146"
    test_sign = hashlib.md5(f"{MG_SALT}{test_ts}1".encode()).hexdigest()
    expected = "6c8bc9ad59b1cbb100a2e2e72b965eac"
    log(f"[*] 签名验证: {'✅ 通过' if test_sign == expected else '❌ 失败'} ({test_sign})")
    log(f"[*] 盐值: {MG_SALT}")
    log(f"[*] 搜索: {MG_SEARCH}")
    log(f"[*] 播放: {MG_PLAY}")
    log(f"[*] 歌词: {MG_LYRIC}")
    log(f"[🚀] D-kaiser Music: http://localhost:{PORT}")

    from http.server import ThreadingHTTPServer
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    srv.daemon_threads = True
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        log("\n👋 已停止")


if __name__ == "__main__":
    main()