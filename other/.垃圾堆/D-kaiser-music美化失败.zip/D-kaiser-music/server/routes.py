#!/usr/bin/env python3
"""API 路由处理"""
from urllib.parse import quote
from config import log
from core import source_router
from core.source_router import search_music, get_play_url, get_lyrics
from core.kuwo_hi_api import hi_set_cookie, hi_play_url
from core.muguang_api import mg_play_url
from core.task_manager import dl_mgr


def handle_search(body):
    src = body.get("source", "muguang")
    pg = body.get("page", 1)
    songs, tot = search_music(body.get("keyword", ""), src, pg)
    return {"songs": songs, "total": tot}


def handle_download(body):
    cnt = 0
    for idx in body.get("indices", []):
        if 0 <= idx < len(source_router._cache):
            if dl_mgr.add(source_router._cache[idx],
                          body.get("source", "muguang")) is not None:
                cnt += 1
    return {"ok": True, "count": cnt}


def handle_preview(body):
    """预览：暮光走代理rid；酷我聚合先mp3后回退flac，统一走 /api/stream 代理"""
    idx = body.get("index", 0)
    src = body.get("source", "muguang")
    if 0 <= idx < len(source_router._cache):
        song = source_router._cache[idx]
        if song.get("source_tag") == "muguang" or src == "muguang":
            rid = song.get("id")
            return {"url": f"/api/stream?rid={rid}&q=128", "ext": "mp3"}
        else:
            # 酷我聚合：先尝试预览音质(mp3)，失败回退无损(flac)
            url, fmt = hi_play_url(song, low=True)
            if not url:
                url, fmt = hi_play_url(song, low=False)
            if url:
                return {"url": f"/api/stream?url={quote(url, safe='')}",
                        "ext": fmt or "mp3"}
            return {"url": None}
    return {"url": None}


def handle_lyric(body):
    idx = body.get("index", 0)
    src = body.get("source", "muguang")
    if 0 <= idx < len(source_router._cache):
        return {"lrc": get_lyrics(source_router._cache[idx], src)}
    return {"lrc": None}


def handle_cookie(body):
    c = body.get("cookie", "")
    hi_set_cookie(c)
    return {"ok": True}


def handle_dl_remove(body):
    dl_mgr.remove(body.get("id", 0))
    return {"ok": True}


def handle_dl_clear(body):
    dl_mgr.clear_done()
    return {"ok": True}


def handle_dl_status():
    return dl_mgr.status()