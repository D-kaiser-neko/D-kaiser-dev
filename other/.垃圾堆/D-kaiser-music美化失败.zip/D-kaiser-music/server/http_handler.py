#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""HTTP 请求处理器"""
import os
import json
import mimetypes
from urllib.parse import urlparse, parse_qs
from http.server import BaseHTTPRequestHandler

import requests as _requests

from config import log_queue
from server import routes
from server.log_stream import stream_logs
from core.muguang_api import mg_play_url

mimetypes.add_type('application/javascript', '.js')
mimetypes.add_type('text/css', '.css')

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATIC_DIR = os.path.realpath(os.path.join(BASE_DIR, "static"))

_PROXY_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
             "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def _json(self, data, code=200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        length = int(self.headers.get("Content-Length", 0))
        if not length:
            return {}
        try:
            return json.loads(self.rfile.read(length))
        except (ValueError, TypeError):
            return {}

    def _serve_file(self, path, ctype):
        try:
            with open(path, "rb") as f:
                data = f.read()
        except FileNotFoundError:
            self.send_error(404)
            return
        self.send_response(200)
        self.send_header("Content-Type", f"{ctype}; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _proxy_audio(self, url):
        """代理音频流：透传Range，按域名补Referer绕过防盗链"""
        headers = {
            "User-Agent": _PROXY_UA,
            "Accept-Encoding": "identity",
            "Referer": "https://flac.music.hi.cn/",
        }
        if "kuwo.cn" in url:
            headers["Referer"] = "https://www.kuwo.cn/"
        elif "126.net" in url or "163.com" in url:
            headers["Referer"] = "https://music.163.com/"
        elif "qq.com" in url or "qpic.cn" in url:
            headers["Referer"] = "https://y.qq.com/"
        rng = self.headers.get("Range")
        if rng:
            headers["Range"] = rng
        try:
            resp = _requests.get(url, headers=headers, stream=True, timeout=30)
        except Exception:
            self.send_error(502, "Upstream fetch failed")
            return
        try:
            self.send_response(resp.status_code)
            for key in ("Content-Type", "Content-Length",
                        "Content-Range", "Accept-Ranges"):
                val = resp.headers.get(key)
                if val:
                    self.send_header(key, val)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            for chunk in resp.iter_content(65536):
                if chunk:
                    self.wfile.write(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass
        finally:
            resp.close()

    def do_GET(self):
        path = self.path.split("?", 1)[0]
        if path in ("/", "/index.html"):
            self._serve_file(os.path.join(STATIC_DIR, "index.html"), "text/html")
        elif path.startswith("/css/") or path.startswith("/js/"):
            fp = os.path.realpath(os.path.join(STATIC_DIR, path.lstrip("/")))
            if not fp.startswith(STATIC_DIR):
                self.send_error(403)
                return
            ctype = "text/css" if fp.endswith(".css") else "application/javascript"
            self._serve_file(fp, ctype)
        elif path == "/api/logs-stream":
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            stream_logs(self.wfile, log_queue)
        elif path == "/api/dl-status":
            self._json(routes.handle_dl_status())
        elif path == "/api/stream":
            self._handle_stream()
        else:
            self.send_error(404)

    def _handle_stream(self):
        qs = parse_qs(urlparse(self.path).query)
        rid = (qs.get("rid") or [""])[0]
        quality = (qs.get("q") or ["128"])[0]
        direct = (qs.get("url") or [""])[0]
        url = None
        if rid:
            url, _fmt = mg_play_url(rid, quality)
            if not url and quality != "320":
                url, _fmt = mg_play_url(rid, "320")
        elif direct:
            url = direct  # parse_qs 已解码一次，切勿再 unquote
        if not url:
            self.send_error(404, "No upstream audio url")
            return
        self._proxy_audio(url)

    def do_POST(self):
        if self.path == "/api/search":
            self._json(routes.handle_search(self._body()))
        elif self.path == "/api/download":
            self._json(routes.handle_download(self._body()))
        elif self.path == "/api/preview":
            self._json(routes.handle_preview(self._body()))
        elif self.path == "/api/lyric":
            self._json(routes.handle_lyric(self._body()))
        elif self.path == "/api/cookie":
            self._json(routes.handle_cookie(self._body()))
        elif self.path == "/api/dl-remove":
            self._json(routes.handle_dl_remove(self._body()))
        elif self.path == "/api/dl-clear":
            self._json(routes.handle_dl_clear(self._body()))
        else:
            self.send_error(404)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Range")
        self.send_header("Access-Control-Max-Age", "86400")
        self.end_headers()